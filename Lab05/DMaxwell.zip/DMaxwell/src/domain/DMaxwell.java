package domain;
import java.util.*;
public class DMaxwell {

    private int width;
    private int height;
    private ArrayList<Particle> particles = new ArrayList<>();

    public DMaxwell(int h, int w, int r, int b, int o){
        height = h;
        width = w;
    }

    public void moveNorth(){

    }

    public void moveWest(){


    }

    public void moveSouth(){

    }

    public void moveEast(){

    }

    public int[] consult(){
        int[] particles = new int[5];
        return particles;
    }

    public void container(){

    }


}