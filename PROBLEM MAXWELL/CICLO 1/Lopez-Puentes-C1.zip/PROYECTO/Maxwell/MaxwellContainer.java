import java.util.ArrayList;
import java.util.Arrays;
import java.util.*;
import javax.swing.JOptionPane;

/**
 * MaxwellContainer.
 * 
 * @author (Juan Sebastian Puentes Julio y Julian Camilo Lopez Barrero) 
 * @version (4/03/2025)
 */
public class MaxwellContainer{
    
    private Rectangle backgroundBoard = new Rectangle();
    private Rectangle leftBoard = new Rectangle();
    private Rectangle rightBoard = new Rectangle();
    private Particles particle;
    private Hole hole;
    private ArrayList<Demon> demons = new ArrayList<>();
    private ArrayList<Particles> particlesAvailables = new ArrayList<>();
    private ArrayList<Hole> holes = new ArrayList<>();
    private boolean lastOperation = false;
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    /**
     * Constructor de MaxwellContainer.
     * @param height
     * @param weight
     */
    public MaxwellContainer(int h, int w){
        //back
        backgroundBoard.changeColor("black");
        backgroundBoard.changeSize(h + 20, w * 2 + 40);
        backgroundBoard.moveHorizontal(-10);
        backgroundBoard.moveVertical(-10);
        //LeftBoard
        leftBoard.changeColor("white");
        leftBoard.changeSize(h,w);
        //RightBoard
        rightBoard.changeColor("white");
        rightBoard.changeSize(h,w);
        rightBoard.moveHorizontal(w+20);
        
    }
    
    /**
     * Constructor of MaxwellContainer with multiple parameters
     * @param h height of the container
     * @param w width of the container.
     * @param d number of demons
     * @param b number of blue balls
     * @param r number of red balls
     * @param particles array of particles
     * @param particles list of the particle´s position
     */
    public MaxwellContainer(int h, int w, int d, int b, int r, int[][] particles) {
        if(h<0) lastOperation = false;
        backgroundBoard.changeColor("black");
        backgroundBoard.changeSize(h + 20, w * 2 + 40);
        backgroundBoard.moveHorizontal(-10);
        backgroundBoard.moveVertical(-10);
        leftBoard.changeColor("white");
        leftBoard.changeSize(h,w);
        rightBoard.changeColor("white");
        rightBoard.changeSize(h,w);
        rightBoard.moveHorizontal(w+20);
        lastOperation = true;
        width = w;
        height = h;
        addDemon(d);
        int total = b+r;
        for (int i = 0; i < particles.length; i++) {
            if (total <= r) {
                addParticle("blue", false, particles[i][0], particles[i][1], particles[i][2], particles[i][3]);
                continue;
            }
            addParticle("red", true, particles[i][0], particles[i][1], particles[i][2], particles[i][3]);
            total--;
        }
    }

    /**
     * Method to add a demon in an specific Vertical Position
     * @param vertical Distance
     * @return void
     */
    public void addDemon(int d) {
        if (15 <= d && d <= leftBoard.getHeight() - 20) {
            for (Demon existingDemon : demons) {
                if (Math.abs(existingDemon.getY() - d) < 20) { 
                    JOptionPane.showMessageDialog(null, "There is already a Demon in that position");
                    lastOperation = false;
                    return;
                }
            }
            Demon demon = new Demon();
            demon.moveHorizontalDemon(leftBoard.getWidth());
            demon.moveVerticalDemon(d-15);
            demons.add(demon);
            lastOperation = true;
        } 
        else {
            JOptionPane.showMessageDialog(null, "Invalid Range");
            lastOperation = false;
        }
    } 
    
    /**
     * Method to del a demon in an specific Vertical Position
     * @param vertical Distance
     * @return void
     */
    public void delDemon(int d) {
        for (int i = 0; i < demons.size(); i++) {
            if (demons.get(i).getY() == d) {
                demons.get(i).makeInvisibleDemon();
                demons.remove(i);
                lastOperation = true;
                i--; //Making sure that in the arrayList dont have repeted indexes.
            } 
            else {
            lastOperation = false;
            }
        }
    
        if (!lastOperation) {
        JOptionPane.showMessageDialog(null, "No Demon found at that position");
        }
    }
    
    /**
     * Method to add particles 
     * @param color of the particle
     * @param boolean if the color is red or no
     * @param px position horizontal of the particle
     * @param py position vertical of the particle
     * @param vx velocity horizontal of the particle
     * @param vy velocity vertical of the particle
     * @return void
     */
    public void addParticle(String color, boolean isRed, int px, int py, int vx, int vy) {
        if (px < 70 || px > backgroundBoard.getWidth() || py < 15 || py > leftBoard.getHeight()) {
            JOptionPane.showMessageDialog(null, "Invalid Range.");
            lastOperation = false;
            return;
        }
        Particles particle = new Particles(color, px, py, vx, vy);
        particlesAvailables.add(particle);
        lastOperation = true;
    }
    
    /**
     * Method to do the movement of the particles
     */
    public void moveParticles() {
        for (Particles particle : particlesAvailables) {
            particle.move();
            checkCollision(particle);
        }
    }
    
    /**
     * Method to check if the particles have a collition
     * @param arraylist particles
     */
    private void checkCollision(Particles particle) {
        int px = particle.getX();
        int py = particle.getY();
        int vx = particle.getVx();
        int vy = particle.getVy();
        int size = 15; 
        int minXLeftBoard = 70;
        int maxXLeftBoard = ((leftBoard.getX() + leftBoard.getWidth() - size));
        int minXRightBoard = rightBoard.getX();
        int maxXRightBoard = rightBoard.getX() + rightBoard.getWidth() - size;
        int minY = 15; 
        int maxY = leftBoard.getY() + leftBoard.getHeight() - size;
        if(particle.getColor().equals("red")){
            if (px <= minXLeftBoard) {
                particle.setVx(Math.abs(vx));
            }else if (px >= maxXLeftBoard) {
                particle.setVx(-Math.abs(vx));
            } 
        }else{
            if (px <= minXRightBoard) {
                particle.setVx(Math.abs(vx));
            } else if (px >= maxXRightBoard) {
                particle.setVx(-Math.abs(vx));
            } 
        }
        
        if (py <= minY) {
                particle.setVy(Math.abs(vy));
            } else if (py >= maxY) {
                particle.setVy(-Math.abs(vy));
            }
    }
    
    /**
     * Method to delete a particle of an specific color
     * @param the color of the particle
     * @return void
     */
    public void delParticle(String color) {
        for (int i = 0; i < particlesAvailables.size(); i++) {
            Particles p = particlesAvailables.get(i);
            if (p.getColor().equals(color)) {
            p.makeInvisibleParticle();  
            particlesAvailables.remove(i);
            lastOperation = true;
            return;  
            }
        }
        JOptionPane.showMessageDialog(null, "Not Particle Found.");
        lastOperation = false;
    }

    /**
     * Method to add a hole with his position and nunber of particles to being eating
     * @param position horizontal of the hole
     * @param position vertical of the hole
     * @param number of particles to be eating
     * @return void
     */
    public void addHole(int px, int py, int particles){
        int countEatingParticles = 0;
        if (15 <= py && py <= leftBoard.getHeight() - 20 &&  70 <= px && px <= leftBoard.getWidth() - 20 ||
            rightBoard.getX() <= px && px <= rightBoard.getX() + rightBoard.getWidth()){ // No pass Board Size
            Hole hole = new Hole(px,py,30,30);
            holes.add(hole);
            lastOperation = true;
        }
    }
    
    /**
     * Method to start the game
     * @param ticks number of ticks
     * @return void
     */
    public void start(int ticks) {
        for (int i = 0; i < ticks; i++) {
            moveParticles();
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Method to verify if the game ends
     * @return void
     */
    public boolean isGoal(){
        return true;
    }
    
    /**
     * Method to see the position x and y of the particles
     * @return void
     */
    public int[][] particles() {
        
        int[][] positions = new int[particlesAvailables.size()][2];
        for (int i = 0; i < particlesAvailables.size(); i++) {
            Particles p = particlesAvailables.get(i);
            positions[i][0] = p.getX();
            positions[i][1] = p.getY();
        }
        //Bubble Sort 
        for (int i = 0; i < positions.length - 1; i++) {
            for (int j = 0; j < positions.length - 1 - i; j++) {
                if (positions[j][0] > positions[j + 1][0]) {
                    int[] aux = positions[j];
                    positions[j] = positions[j + 1];
                    positions[j + 1] = aux;
            }
            }
        }
        return positions;
    }
    
    /**
     * Method to see the position x and y of the holes
     * @return void
     */
    public int[][] holes() {
        int[][] positions = new int[holes.size()][2];
        for (int i = 0; i < holes.size(); i++) {
            Hole h = holes.get(i);
            positions[i][0] = h.getX();
            positions[i][1] = h.getY();
        }
        return positions;
    }
    
    /**
     * Method to make visible all the game 
     * @return void
     */
    public void makeVisible(){
        makeVisibleBoards();
        for(Demon demon: demons){
            demon.makeVisibleDemon();   
        }
        
        for(Hole hole: holes){
            hole.makeVisibleHole();
        }
        
        for(Particles particle : particlesAvailables){
            particle.makeVisibleParticle();
        }
    }
    
    /**
     * Method to make Invisible all the game 
     * @return void
     */
    public void makeinVisible(){
        makeInVisibleBoards();
        for(Demon demon: demons){
            demon.makeInvisibleDemon();   
        }
        
        for(Hole hole: holes){
            hole.makeInvisibleHole();
        }
        
        for(Particles particle : particlesAvailables){
            particle.makeInvisibleParticle();
        }
        
    }
    
    /**
     * Method to do visible leftBoard, rightBoard and backgroundBoard
     */
    private void makeVisibleBoards(){
        backgroundBoard.makeVisible();
        leftBoard.makeVisible();
        rightBoard.makeVisible();
    }
    
    /**
     * Method to do Invisible leftBoard, rightBoard and backgroundBoard
     */
    private void makeInVisibleBoards(){
        backgroundBoard.makeInvisible();
        leftBoard.makeInvisible();
        rightBoard.makeInvisible();
    }
    
    /**
     * Method to  end the game.
     * @return void
     */
    public void finish(){
        makeinVisible();
        particlesAvailables.clear();
        holes.clear();
        demons.clear();
        Canvas.getCanvas().close();
    }
    
    /**
     * Verify if the last operation is valid or not
     * @return Boolean
     */
    public boolean ok(){
        return lastOperation;
    }
    
}


