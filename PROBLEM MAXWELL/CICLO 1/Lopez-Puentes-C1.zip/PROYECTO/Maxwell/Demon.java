
/**
 * Class Demon 
 * 
 * @author (Julian Camilo Lopez Barrero && Juan Sebastian Puentes Julio) 
 * @version (07/03/2025)
 */
public class Demon
{
    private int x;
    private int y;
    private Rectangle demon;
    /**
     * Constructor of Demon.
     */
    public Demon() {
        demon = new Rectangle();
        x = demon.getX();
        y = demon.getY();
        demon.changeSize(20, 20);   
        demon.changeColor("red");
    }
    
    /**
     * Move demon vertical
     * @param distance
     */
    public void moveVerticalDemon(int distance) {
        demon.moveVertical(distance);
    }
    
    /**
     * Move the demon vertical
     * @param distance
     */
    public void moveHorizontalDemon(int distance) {
        demon.moveHorizontal(distance);
    }
    /**
     * Get the X position
     */
    public int getX() {
        return this.x;
    }
    
    /**
     * Get the Y position
     */
    public int getY() {
        return this.y;
    }
    
    /**
     * Make Visible the demon
     */
    public void makeVisibleDemon(){
        demon.makeVisible();
    }
    /**
     * Make InVisible the demon
     */
    public void makeInvisibleDemon(){
        demon.makeInvisible();
    }



}
