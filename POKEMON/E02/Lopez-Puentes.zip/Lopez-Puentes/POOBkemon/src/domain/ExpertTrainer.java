package src.domain;

public class ExpertTrainer extends MachineTrainer {
    public ExpertTrainer(String name) {
        super(name);
    }

    @Override
    public Movement decide(Pokemon target) { //FALTA
        return null;
    }
}
