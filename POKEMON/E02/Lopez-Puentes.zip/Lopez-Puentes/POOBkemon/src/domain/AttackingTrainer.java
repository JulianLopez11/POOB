package src.domain;

public class AttackingTrainer extends MachineTrainer {
    public AttackingTrainer(String name) {
        super(name);
    }

    @Override
    public Movement decide(Pokemon target) { //FALTA
        return null;
    }
}
